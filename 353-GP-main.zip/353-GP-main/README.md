<h1>Natural Disasters and Temperature Analysis</h1>
This project analyzes the relationship between natural disasters and temperature data. It includes several Python scripts.

<h3>Requirements</h3>
Python 3.x
Pandas library
